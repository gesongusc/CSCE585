
import time
import tensorflow as tf
from tensorflow.keras.models import Sequential
from keras.optimizers import Adam,SGD
#--------------------------------------------------------
import os
import csv
import keras
from keras.models import Model
from keras.layers import Input, RNN, Dense, Layer,Lambda,Add,Subtract
from keras.layers import Embedding
import numpy as np
from sklearn.externals import joblib
import matplotlib.pyplot as plt
from tbad.rnn_autoencoder.rnn import load_architecture_specification
from tbad.combined_model.message_passing import MessagePassingEncoderDecoder
from tbad.utils import select_cell, select_optimiser, select_loss

from copy import deepcopy
from definition import load_data,load_output,get_data,load_test
import numpy as np
from sklearn.externals import joblib
from sklearn.utils import shuffle

from tbad.autoencoder.data import load_trajectories, split_into_train_and_test, extract_global_features
from tbad.autoencoder.data import change_coordinate_system, scale_trajectories, aggregate_autoencoder_data
from tbad.autoencoder.data import input_trajectories_missing_steps,load_anomaly_masks,assemble_ground_truth_and_reconstructions
from tbad.rnn_autoencoder.data import remove_short_trajectories, aggregate_rnn_autoencoder_data,summarise_reconstruction_errors
from tbad.combined_model.fusion import CombinedEncoderDecoder
from tbad.combined_model.message_passing import MessagePassingEncoderDecoder
from tbad.utils import set_up_logging, resume_training_from_last_epoch
class ElapsedTimer(object):
    def __init__(self):
        self.start_time = time.time()
    def elapsed(self,sec):
        if sec < 60:
            return str(sec) + " sec"
        elif sec < (60 * 60):
            return str(sec / 60) + " min"
        else:
            return str(sec / (60 * 60)) + " hr"
    def elapsed_time(self):
        print("Elapsed: %s " % self.elapsed(time.time() - self.start_time) )

class ADGAN(object):
    def __init__(self):


        self.channel = 1
        self.D = None   # discriminator
        self.G = None   # generator
        self.AM = None  # adversarial model
        self.DM = None  # discriminator model

    # (W-F+2P)/S+1
#    def discriminator(self):
##        self.D = Sequential()
##        self.D.add(Embedding(input_dim=34,output_dim=34))
##        self.D.add(tf.keras.layers.LSTM(16))
##        self.D.add(tf.keras.layers.Dense(1,activation='sigmoid'))
##
##        self.D.summary()
#        x = Input(shape=(12,34))
#        self.noise = keras.backend.constant(np.random.normal(0,40,[12,34]),dtype='float32')
#        x_loss = Dense(units=1,activation='sigmoid')(x)
#        noise_loss = Dense(units=1,activation='sigmoid')(x)
#        total_loss = Add()([x_loss,noise_loss])
#
#        #x = Embedding(12,34)
##        lstm = keras.layers.LSTM(16)
##        output = lstm(x_now)
##        sigmoid = keras.layers.Activation('sigmoid')
##        output = sigmoid(output)
#        optimizer = Adam(lr=0.001)
#        self.D = Model(inputs=x,outputs=total_loss)
#        self.D.compile(loss='mean_squared_error', optimizer=optimizer)
#        return self.D
#    
#    def generator(self):
#
#        global_input_layer = Input(shape=(12, 4), name='global_enc_input',
#                                 dtype='float32')
#        global_enc_input = global_input_layer
#
#
#        global_enc_cells = [select_cell('gru', 8, l1=0.0, l2=0.0)]
#        global_enc_rnn = RNN(cell=global_enc_cells, return_state=True, name='global_enc_rnn')
#        # global_embedding = Dense(units=16, activation='relu')
#        _, *global_enc_states = global_enc_rnn(global_enc_input)
#
#        # Global Model - Reconstruction Branch
#        global_rec_input = global_input_layer#Input(shape=(12, 4), name='global_rec_input',
#                                 #dtype='float32')
#
#
#        global_rec_cells = [select_cell('gru', 8, l1=0.0, l2=0.0)]
#        global_rec_rnn = RNN(cell=global_rec_cells, return_sequences=True, name='global_rec_rnn')
#        global_rec_output = global_rec_rnn(global_rec_input, initial_state=global_enc_states)
#        global_rec_dense = Dense(units=4, activation='linear', name='global_rec_dense')
#        global_rec_output = global_rec_dense(global_rec_output)
#        
#        # Local Model
#        local_input_layer = Input(shape=(12, 34), name='local_enc_input',dtype='float32')
#        local_enc_input = local_input_layer#Input(shape=(12, 34), name='local_enc_input',
#                                #dtype='float32')
#
#
#
#        local_enc_cells = [select_cell('gru', 8, l1=0.0, l2=0.0)]
#        local_enc_rnn = RNN(cell=local_enc_cells, return_state=True, name='local_enc_rnn')
#        # local_embedding = Dense(units=136, activation='relu')
#        _, *local_enc_states = local_enc_rnn(local_enc_input)
#
#        # Local Model - Reconstruction Branch
#        local_rec_input = local_input_layer#Input(shape=(12, 34), name='local_rec_input',
#                                #dtype='float32')
#
#
#
#        local_rec_cells = [select_cell('gru', 8, l1=0.0, l2=0.0)]
#        local_rec_rnn = RNN(cell=local_rec_cells, return_sequences=True, name='local_rec_rnn')
#        local_rec_output = local_rec_rnn(local_rec_input, initial_state=local_enc_states)
#        local_rec_dense = Dense(units=34, activation='linear', name='local_rec_dense')
#        local_rec_output = local_rec_dense(local_rec_output)
##-----------------------output------------------------------------------        
#        rec_output = keras.layers.concatenate(inputs=[global_rec_output, local_rec_output], axis=-1)
#        self.multiple_outputs=True
#        self.multiple_outputs_before_concatenation=True
#        self.extra_hidden_dims=False
#        self.reconstruct_original_data=True
#        self.prediction_length=12
#        self.output_activation='linear'
#        out_dim = 34
#
#        if self.extra_hidden_dims:
#            for hidden_dim in self.extra_hidden_dims:
#                rec_output = Dense(units=hidden_dim, activation='relu')(rec_output)
#            rec_output = Dense(units=out_dim, activation=self.output_activation)(rec_output)
#        elif self.reconstruct_original_data:
#            rec_output = Dense(units=out_dim, activation=self.output_activation)(rec_output)
#        self.G = Model(inputs=[global_input_layer,local_input_layer],outputs=rec_output)
#        return self.G
        
#    def discriminator_model(self):
##        if self.DM:
##            return self.DM
#        optimizer = Adam(lr=0.001)
##        self.DM = Sequential()
##        self.DM.add(self.discriminator())
#        #x = Input(shape=(12,34))
#        output = self.discriminator()
#        self.DM = Model(inputs=self.discriminator.input,outputs=output)
#        self.DM.compile(loss='mean_squared_error', optimizer=optimizer)
#        return self.DM

    def adversarial_model(self):
        if self.AM:
            return self.AM
        optimizer = SGD(lr=0.001,momentum=0.9)
        self.noise = np.random.normal(0,40,34)
#        self.AM = Sequential()
#        self.AM.add(self.generator())
#        self.AM.add(self.discriminator())
        #x = Input(shape=(12,34))
#        G = self.generator()
#        D = self.discriminator()
#        output = D(G)
        global_input_layer_am = Input(shape=(12, 4), name='global_enc_input_am',
                                 dtype='float32')
        global_enc_input_am = global_input_layer_am


        global_enc_cells_am = [select_cell('gru', 8, l1=0.0, l2=0.0)]
        global_enc_rnn_am = RNN(cell=global_enc_cells_am, return_state=True, name='global_enc_rnn_am')
        # global_embedding = Dense(units=16, activation='relu')
        _, *global_enc_states_am = global_enc_rnn_am(global_enc_input_am)

        # Global Model - Reconstruction Branch
        global_rec_input_am = global_input_layer_am#Input(shape=(12, 4), name='global_rec_input',
                                 #dtype='float32')


        global_rec_cells_am = [select_cell('gru', 8, l1=0.0, l2=0.0)]
        global_rec_rnn_am = RNN(cell=global_rec_cells_am, return_sequences=True, name='global_rec_rnn_am')
        global_rec_output_am = global_rec_rnn_am(global_rec_input_am, initial_state=global_enc_states_am)
        global_rec_dense_am = Dense(units=4, activation='linear', name='global_rec_dense_am')
        global_rec_output_am = global_rec_dense_am(global_rec_output_am)
        
        # Local Model
        local_input_layer_am = Input(shape=(12, 34), name='local_enc_input_am',
                                 dtype='float32')
        local_enc_input_am = local_input_layer_am#Input(shape=(12, 34), name='local_enc_input',
                                #dtype='float32')


        local_enc_cells_am = [select_cell('gru', 8, l1=0.0, l2=0.0)]
        local_enc_rnn_am = RNN(cell=local_enc_cells_am, return_state=True, name='local_enc_rnn_am')
        # local_embedding = Dense(units=136, activation='relu')
        _, *local_enc_states_am = local_enc_rnn_am(local_enc_input_am)

        # Local Model - Reconstruction Branch
        local_rec_input_am = local_input_layer_am#Input(shape=(12, 34), name='local_rec_input',
                                #dtype='float32')


        local_rec_cells_am = [select_cell('gru', 8, l1=0.0, l2=0.0)]
        local_rec_rnn_am = RNN(cell=local_rec_cells_am, return_sequences=True, name='local_rec_rnn_am')
        local_rec_output_am = local_rec_rnn_am(local_rec_input_am, initial_state=local_enc_states_am)
        local_rec_dense_am = Dense(units=34, activation='linear', name='local_rec_dense_am')
        local_rec_output_am = local_rec_dense_am(local_rec_output_am)
#-----------------------output------------------------------------------        
        rec_output_am = keras.layers.concatenate(inputs=[global_rec_output_am, local_rec_output_am], axis=-1)
        self.multiple_outputs=True
        self.multiple_outputs_before_concatenation=True
        self.extra_hidden_dims=False
        self.reconstruct_original_data=True
        self.prediction_length=12
        self.output_activation='linear'
        out_dim = 34

        if self.extra_hidden_dims:
            for hidden_dim in self.extra_hidden_dims:
                rec_output_am = Dense(units=hidden_dim, activation='relu',name='dense1')(rec_output_am)
            rec_output_am = Dense(units=out_dim, activation=self.output_activation,name='dense2')(rec_output_am)
        elif self.reconstruct_original_data:
            rec_output_am = Dense(units=out_dim, activation=self.output_activation,name='dense3')(rec_output_am)
        noise_am = Input(shape=(12, 34), name='noise_am',
                                 dtype='float32')
        origin_am = Input(shape=(12, 34), name='origin_am',
                                 dtype='float32')
        target = Input(shape=(12, 1), name='target',
                                 dtype='float32')
        error_map_am = Subtract()([rec_output_am,origin_am])
        discrimination = Dense(units=1,activation='sigmoid')
        reconstruct_loss = Dense(units=1,activation='linear')(error_map_am)
        x_loss_am = discrimination(error_map_am)
        x_loss_am = Subtract()([target,x_loss_am])
        noise_loss_am = discrimination(noise_am)
        #noise_loss_am = Subtract()([target,noise_loss_am])
        total_loss_am = Add()([x_loss_am,noise_loss_am])
        total_loss_am = Add()([total_loss_am,reconstruct_loss])
        
        self.AM = Model(inputs=[global_input_layer_am,local_input_layer_am,origin_am,noise_am,target],outputs=total_loss_am)
        self.AM.compile(loss='mean_squared_error', optimizer=optimizer)
        return self.AM
        
class MNIST_DCGAN(object):
    def __init__(self):

        self.ADGAN = ADGAN()
        #x = Input(shape=(12,34))
        #self.generator = self.ADGAN.generator()
        #self.discriminator =  self.ADGAN.discriminator()
        self.adversarial = self.ADGAN.adversarial_model()


    def train(self, train_steps=2000, batch_size=256, save_interval=0):
        noise_input = None
        trajectories_path = "/home/gesong2/skeleton_gan/data/My-data/training/trajectory/00/"
        trajectories_path_noise = "/home/gesong2/skeleton_gan/data/My-data/training/trajectory_noise_40/00/"
        x_train,origin_coordinate,global_scaler,local_scaler = get_data(trajectories_path)
        x_train_noise,origin_coordinate_noise,global_scaler_noise,local_scaler_noise = get_data(trajectories_path_noise)
        video_resolution=[1920,1080]
        if save_interval>0:
            noise_input = np.random.normal(0,40,34)
            #noise_input = noise_input.reshape(12,34)
        for i in range(train_steps):
            noise = np.random.normal(0,40,[batch_size,12,34])
            #noise = noise.reshape(12,34)


            pick = np.random.randint(0,x_train.shape[0], size=batch_size)
            data_train = x_train_noise[pick, :, :]
            data_train_global = data_train[:,:,:4]
            data_train_local = data_train[:,:,4:]
            data_origin = origin_coordinate[pick, :, :]
            original_shape = data_origin.shape
            data_origin = data_origin.reshape(original_shape[0],-1, 2) / video_resolution
            data_origin = data_origin.reshape(original_shape)
            #data_train_local = change_coordinate_system(data_train_global, video_resolution=self.video_resolution,
                                                        #coordinate_system='bounding_box_centre', invert=False)
            #trajectory.change_coordinate_system(video_resolution, coordinate_system=coordinate_system, invert=invert)
            #reconstruction_data = self.generator.predict([data_train_global,data_train_local])
#            reconstruction_data = self.generator.predict([data_train_global,data_train_local])
#            error_map = reconstruction_data - data_origin
            #x = np.concatenate((images_train, images_fake))
            #y = np.random.normal(0,40,34)
            y = np.ones([batch_size, 12,1])
            #y[batch_size:, :] = 0
            #d_loss = self.discriminator.train_on_batch(error_map,y)

            y_p = np.zeros([batch_size, 12,1])
            #noise = np.random.normal(0,40,[batch_size, 34])
            a_loss = self.adversarial.train_on_batch([data_train_global,data_train_local,data_origin,noise,y], y_p)
            #print(a_loss)
            #log_mesg = "%d: [A loss: %f]" % (i, a_loss)
            #log_mesg = "%s  [A loss: %f]" % (log_mesg, a_loss)
            #print(log_mesg)

    def test(self):
        trajectories_test_path = "/home/gesong2/skeleton_gan/data/My-data2/testing4/trajectory_4/clean"
        trajectories_test_noise_path = "/home/gesong2/skeleton_gan/data/My-data2/testing4/trajectory_4/01"
        mask_path = "/home/gesong2/skeleton_gan/data/My-data2/testing4/frame_level_masks/01/"
        anomaly_masks = load_anomaly_masks(mask_path)
        #print(anomaly_masks.shape)
        x_test,origin_coordinate,global_scaler,local_scaler = get_data(trajectories_test_path)
        #file_1 = open("/home/gesong2/skeleton_gan/data/My-data2/testing3/trajectories/01/0003/001.csv")
#        file_2 = open("/home/gesong2/skeleton_gan/data/My-data2/testing3/trajectory_noise_40/01/0003/001.csv")
        #x_test = np.loadtxt(file_1,delimiter=",")
#        x_test_noise = np.loadtxt(file_2,delimiter=",")
        #x_test = np.reshape(x_test,[1,x_test.shape[0],x_test.shape[1]])
#        x_test_noise = np.reshape(x_test_noise,[1,x_test_noise.shape[0],x_test_noise.shape[1]])
        x_test_noise,origin_coordinate_noise,global_scaler_noise,local_scaler_noise = get_data(trajectories_test_noise_path)
        noise = np.random.normal(0,40,[1,12,34])
#        trajectories_ids,frames,X_global_noise,X_local_noise,X_init_noise= load_test(trajectories_test_noise_path,global_scaler_noise,local_scaler_noise)
#        _,_,_,_,X_init= load_test(trajectories_test_path,global_scaler_noise,local_scaler_noise)
#        print(frames)
#        print(trajectories_ids)
        #noise = np.random.normal(0,40,[X_init.shape[0],12,34])
        y = np.ones([1,12,1])
        #y = np.ones([X_init.shape[0],12,1])
        video_resolution=[1920,1080]
        #-------------------------------------------------------------------------------------------
#        total_loss = []
        with open("/home/gesong2/skeleton_gan/T4001_01_gru.csv",'w') as csvfile:
            csvwriter = csv.writer(csvfile)
            for i in range(0,x_test.shape[0]-1):
                timer = ElapsedTimer()
                data_test = x_test_noise[i, :, :]
                data_test_global = data_test[:,:4]
                data_test_global = np.reshape(data_test_global,[1,12,4])
                data_test_local = data_test[:,4:]
                data_test_local = np.reshape(data_test_local,[1,12,34])
                data_origin = origin_coordinate[i, :, :]
                original_shape = data_origin.shape
                data_origin = data_origin.reshape(-1, 2) / video_resolution
                data_origin = data_origin.reshape(original_shape)
                data_origin = np.reshape(data_origin,[1,12,34])
                loss = self.adversarial.predict([data_test_global,data_test_local,data_origin,noise,y])
                loss_ave = [np.absolute(np.average(loss))]
                
                timer.elapsed_time()
                csvwriter.writerow(loss_ave)
                #-------------------------------------------------------------------
        
#        loss = self.adversarial.predict([X_global_noise,X_local_noise,X_init,noise,y],batch_size=1024)
#        reconstruction_ids, reconstruction_frames, reconstruction_errors = \
#    summarise_reconstruction_errors(loss, frames[:, :12], trajectories_ids[:, :12])
#        y_true, y_hat, video_ids = assemble_ground_truth_and_reconstructions(anomaly_masks, reconstruction_ids,
#                                                                     reconstruction_frames, reconstruction_errors, return_video_ids=True)
#        avg = 15
#        average_errors = []
#        for i, j in enumerate(y_hat):
#            if i < avg:
#        #print(len(current_errors[0:i+1]))
#                average_errors.append((sum(y_hat[0:i+1])/len(y_hat[0:i+1])))
#            else:
#                average_errors.append((sum(y_hat[i-avg+1:i+1])/len(y_hat[i-avg+1:i+1])))
#        plt.axvline(int(0.45*len(y_hat)),color='red',linestyle='dashed')
#        plt.axvline(int(0.78*len(y_hat)),color='red',linestyle='dashed')
##        plt.axvline(800,color='red',linestyle='dashed')
##        plt.axvline(1500,color='red',linestyle='dashed')
#        plt.plot(average_errors, label = 'Averaged loss')
##plt.axhline(y=0.15, color = 'g', label = 'Threshold', linestyle='dashed')
##plt.plot(ground_truth)
#        plt.xlabel('Frame numbers')
#        #plt.ylabel('Frame-level reconstruction error')
#        plt.ylabel('Ground truth')
#        plt.legend()
#        #plt.savefig("Test3_sgd.jpg",bbox_inches = 'tight', dpi = 300)
#        plt.show()
    
#        loss_ave = [np.absolute(np.average(loss))]
#        print(len(loss))
            
        print('DONE!')
        #with open("/home/gesong2/skeleton_gan/001_result.csv",'w') as csvfile:
            #csvwriter = csv.writer(csvfile)
            #csvwriter.writerow(total_loss)



if __name__ == '__main__':
    mnist_dcgan = MNIST_DCGAN()
    #timer = ElapsedTimer()
    mnist_dcgan.train(train_steps=2000, batch_size=256, save_interval=10)
    #timer = ElapsedTimer()
    mnist_dcgan.test()
    #timer.elapsed_time()