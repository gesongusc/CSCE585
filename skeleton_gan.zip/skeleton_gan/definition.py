import numpy as np
from tbad.autoencoder.data import load_trajectories, split_into_train_and_test, extract_global_features,copy_coordinate
from copy import deepcopy
from tbad.autoencoder.data import change_coordinate_system, scale_trajectories, aggregate_autoencoder_data
from tbad.rnn_autoencoder.data import remove_short_trajectories, aggregate_rnn_autoencoder_data, aggregate_rnn_ae_evaluation_data
def preprocess(X_train,y_train=None):
    if True:
            X_global_train, X_local_train, X_out_train = X_train
            X_global_val, X_local_val, X_out_val = val_data[0]
    else:
            X_global_train, X_local_train = X_train
            X_global_val, X_local_val = val_data[0]

    X = _construct_input_data(X_global_train, X_local_train)
    X_val = _construct_input_data(X_global_val, X_local_val)

    if y_train is not None:
        if True:
            y_global_train, y_local_train, y_out_train = y_train
            y_global_val, y_local_val, y_out_val = val_data[1]
        else:
            y_global_train, y_local_train = y_train
            y_global_val, y_local_val = val_data[1]
            y_out_train = y_out_val = None
    else:
        y_global_train = y_local_train = y_out_train = y_global_val = y_local_val = y_out_val = None

    if True:
        y = _construct_output_data_alt(X_out_train, y_out_train,
                                                X_global_train, y_global_train, X_local_train, y_local_train)
        y_val = _construct_output_data_alt(X_out_val, y_out_val,
                                                    X_global_val, y_global_val, X_local_val, y_local_val)
    else:
        y = _construct_output_data(X_global_train, X_local_train, y_global_train, y_local_train)
        y_val = _construct_output_data(X_global_val, X_local_val, y_global_val, y_local_val)
        
    return y
    
def reconstruct(global_features, local_features,prediction_length=6):
    if prediction_length > 0:
        reconstructed_features = {trajectory_id: self.predict([global_features[trajectory_id],
                                                                   local_features[trajectory_id]], batch_size=256)[0]
                                      for trajectory_id in global_features.keys()}
    else:
        reconstructed_features = {trajectory_id: self.predict([global_features[trajectory_id],
                                                                   local_features[trajectory_id]], batch_size=256)
                                      for trajectory_id in global_features.keys()}
        
    return reconstructed_features
    
def _construct_input_data(X_global, X_local,prediction_length=6,reconstruction_length=12,global_input_dim=4,local_input_dim=34):
    X = [X_global]

    n_examples = X_global.shape[0]
    X.append(np.zeros((n_examples, reconstruction_length, global_input_dim), dtype=np.float32))

    if prediction_length > 0:
        X.append(np.zeros((n_examples, prediction_length, global_input_dim), dtype=np.float32))

    X.append(X_local)

    X.append(np.zeros((n_examples, reconstruction_length, local_input_dim), dtype=np.float32))

    if prediction_length > 0:
        X.append(np.zeros((n_examples, prediction_length, local_input_dim), dtype=np.float32))

    return X

def _construct_output_data(X_global, X_local, y_global=None, y_local=None,prediction_length=6,reconstruction_length=12):
    y = []

    X = np.concatenate((X_global, X_local), axis=-1)
    if True:
        if True:
            y.append(X_global[:, (reconstruction_length - 1)::-1, :])
            y.append(X_local[:, (reconstruction_length - 1)::-1, :])
            y.append(X[:, (reconstruction_length - 1)::-1, :])
        else:
            y.append(X_global[:, :reconstruction_length, :])
            y.append(X_local[:, :reconstruction_length, :])
            y.append(X[:, :reconstruction_length, :])

        if prediction_length > 0:
            y.append(y_global)
            y.append(y_local)
            y.append(np.concatenate((y_global, y_local), axis=-1))
    else:
        if True:
            y.append(X[:, (reconstruction_length - 1)::-1, :])
        else:
            y.append(X[:, :reconstruction_length, :])

        if prediction_length > 0:
            y.append(np.concatenate((y_global, y_local), axis=-1))

    return y
    
def load_data(trajectories_train,video_resolution,reconstruct_original_data=True):
    input_length=12
    pred_length=6
    global_normalisation_strategy='robust'
    local_normalisation_strategy='robust'
    global_trajectories_train = extract_global_features(deepcopy(trajectories_train), video_resolution=video_resolution)
    global_trajectories_coordinate = copy_coordinate(deepcopy(trajectories_train))



    global_trajectories_train = change_coordinate_system(global_trajectories_train, video_resolution=video_resolution,
                                                         coordinate_system='global', invert=False)

    #print(global_trajectories_train.values())
    print('\nChanged global trajectories\'s coordinate system to global.')

    _, global_scaler = scale_trajectories(aggregate_autoencoder_data(global_trajectories_train),
                                          strategy=global_normalisation_strategy)

    X_global_train, y_global_train = aggregate_rnn_autoencoder_data(global_trajectories_train,
                                                                    input_length=input_length,
                                                                    input_gap=0, pred_length=pred_length)
    X_global_coordinate,y_global_coordinate  = aggregate_rnn_autoencoder_data(global_trajectories_coordinate,
                                                                    input_length=input_length,
                                                                    input_gap=0, pred_length=pred_length)


    X_global_train, _ = scale_trajectories(X_global_train, scaler=global_scaler, strategy=global_normalisation_strategy)
    if y_global_train is not None:
        y_global_train, _ = scale_trajectories(y_global_train, scaler=global_scaler,
                                               strategy=global_normalisation_strategy)
    print('\nNormalised global trajectories using the %s normalisation strategy.' % global_normalisation_strategy)

    # Local
    local_trajectories_train = deepcopy(trajectories_train) if reconstruct_original_data else trajectories_train

    local_trajectories_train = change_coordinate_system(local_trajectories_train, video_resolution=video_resolution,
                                                        coordinate_system='bounding_box_centre', invert=False)

    print('\nChanged local trajectories\'s coordinate system to bounding_box_centre.')

    _, local_scaler = scale_trajectories(aggregate_autoencoder_data(local_trajectories_train),
                                         strategy=local_normalisation_strategy)

    X_local_train, y_local_train = aggregate_rnn_autoencoder_data(local_trajectories_train, input_length=input_length,
                                                                  input_gap=0, pred_length=pred_length)


    X_local_train, _ = scale_trajectories(X_local_train, scaler=local_scaler, strategy=local_normalisation_strategy)
    if y_local_train is not None:
        y_local_train, _ = scale_trajectories(y_local_train, scaler=local_scaler, strategy=local_normalisation_strategy)
    print('\nNormalised local trajectories using the %s normalisation strategy.' % local_normalisation_strategy)
    return X_global_train, y_global_train,X_local_train, y_local_train,X_global_coordinate,global_scaler,local_scaler
    
def load_output(trajectories_train,video_resolution):
    print('\nReconstruction/Prediction target is the original data.')
    out_trajectories_train = trajectories_train

    out_trajectories_train = change_coordinate_system(out_trajectories_train, video_resolution=video_resolution,
                                                          coordinate_system='global', invert=False)

    print('\nChanged target trajectories\'s coordinate system to global.')

    _, out_scaler = scale_trajectories(aggregate_autoencoder_data(out_trajectories_train),
                                           strategy='robust')

    X_out_train, y_out_train = aggregate_rnn_autoencoder_data(out_trajectories_train, input_length=12,
                                                                  input_gap=0, pred_length=6)
  
    X_out_train, _ = scale_trajectories(X_out_train, scaler=out_scaler, strategy='robust')
    print('\nNormalised target trajectories using the ROBUST normalisation strategy.' ) 
    return X_out_train, y_out_train 
    
def get_data(trajectories_path):
    trajectories = load_trajectories(trajectories_path)
    print('\nLoaded %d trajectories.' % len(trajectories))
    
    trajectories = remove_short_trajectories(trajectories, input_length=12,
                                                 input_gap=0, pred_length=6)
    print('\nRemoved short trajectories. Number of trajectories left: %d.' % len(trajectories))
    
    trajectories_train, trajectories_val = split_into_train_and_test(trajectories, train_ratio=0.8, seed=42)
    video_resolution = [1920,1080]
#-------------------------------------------------------------------------------------------------------------------------
    X_global_train, y_global_train,X_local_train, y_local_train,origin_coordinate,global_scaler,local_scaler=load_data(trajectories_train=trajectories_train,video_resolution=video_resolution)
#-----------------------------------------------------------------------------------------------------------------------------------------
    X_out_train, y_out_train = load_output(trajectories_train=trajectories_train,video_resolution=video_resolution)           
    x_train = np.concatenate((X_global_train,X_local_train),axis=2)
    return x_train, origin_coordinate,global_scaler,local_scaler
    
def load_test(trajectory_path,global_scaler,local_scaler):
    video_resolution=[1920,1080]
    trajectories = load_trajectories(trajectory_path)
    trajectories = remove_short_trajectories(trajectories, input_length=12,
                                             input_gap=0, pred_length=6)
    global_trajectories = extract_global_features(deepcopy(trajectories), video_resolution=video_resolution)

    global_trajectories = change_coordinate_system(global_trajectories, video_resolution=video_resolution,
                                                   coordinate_system='global', invert=False)
                          
    trajectories_ids, frames, X_global = aggregate_rnn_ae_evaluation_data(global_trajectories,
                                         input_length=12,
                                         input_gap=0,
                                         pred_length=6,
                                         overlapping_trajectories = True)

    X_global, _ = scale_trajectories(X_global, scaler=global_scaler, strategy='robust')

    local_trajectories = deepcopy(trajectories)
    local_trajectories = change_coordinate_system(local_trajectories, video_resolution=video_resolution,
                                                  coordinate_system='bounding_box_centre', invert=False)
    _, _, X_local = aggregate_rnn_ae_evaluation_data(local_trajectories, input_length=12,
                                                 input_gap=0, pred_length=6,
                                                 overlapping_trajectories = True)
    X_local, _ = scale_trajectories(X_local, scaler=local_scaler, strategy='robust')
    out_trajectories = trajectories
    out_trajectories = change_coordinate_system(out_trajectories, video_resolution=video_resolution,
                                               coordinate_system='global', invert=False)
    _, _, X_out = aggregate_rnn_ae_evaluation_data(out_trajectories, input_length=12,
                                                   input_gap=0, pred_length=6,
                                                   overlapping_trajectories = True)
    X_out, _ = scale_trajectories(X_out, scaler=None, strategy='robust')
    
    return trajectories_ids,frames,X_global,X_local,X_out