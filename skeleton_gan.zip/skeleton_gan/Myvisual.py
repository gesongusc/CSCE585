import os

import cv2
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tbad.visualisation import draw_skeleton, draw_line, draw_poly, draw_rect, maybe_create_dir
from tbad.visualisation import compute_simple_bounding_box, _render_trajectories_skeletons

COLOURS = {0: (0, 0, 0),  # Black
           1: (255, 0, 0),  # Red
           2: (0, 255, 0),  # Lime
           3: (0, 0, 255),  # Blue
           4: (255, 255, 0),  # Yellow
           5: (0, 255, 255),  # Cyan / Aqua
           6: (255, 0, 255),  # Magenta / Fuchsia
           7: (128, 128, 128),  # Gray
           8: (128, 0, 0),  # Maroon
           9: (128, 128, 0),  # Olive
           10: (0, 128, 0),  # Green
           11: (128, 0, 128),  # Purple
           12: (0, 128, 128),  # Teal
           13: (0, 0, 128),  # Navy
           14: (0, 0, 0),  # White
           15: (192, 192, 192),  # Silver
           16: (220, 20, 60),  # Crimson
           17: (255, 140, 0),  # Dark Orange
           18: (184, 134, 11),  # Dark Golden Rod
           19: (189, 183, 107),  # Dark Khaki
           20: (0, 100, 0)}  # Dark Green


video_path = './original-data/test3/test_003.MOV'
gt_trajectories_path = None
draw_gt_skeleton = None
draw_gt_bounding_box = None
trajectories_path = './pretrained/CVPR19/ShanghaiTech/combined_model/_mp_Grobust_Lrobust_Orobust_concatdown_/00_2021_10_11_11_31_56/reconstructed_skeletons/0003/'
draw_trajectories_skeleton = True
draw_trajectories_bounding_box = True
specific_person_id = None
draw_local_skeleton = None
gt_trajectories_colour = None
trajectories_colour = None
write_dir = './write_dir/testing03/'

if gt_trajectories_path is None and trajectories_path is None:
    raise ValueError('At least one of --ground_truth_trajectories or --trajectories must be specified.')

if not any([draw_gt_skeleton, draw_gt_bounding_box, draw_trajectories_skeleton, draw_trajectories_bounding_box]):
    raise ValueError('At least one of --draw_ground_truth_trajectories_skeleton, '
                     '--draw_ground_truth_trajectories_bounding_box, --draw_trajectories_skeleton or '
                     '--draw_trajectories_bounding_box must be specified.')

if draw_local_skeleton and specific_person_id is None:
    raise ValueError('If --draw_local_skeleton is specified, a --person_id must be chosen as well.')
elif draw_local_skeleton:
    draw_gt_skeleton = draw_trajectories_skeleton = True
    draw_gt_bounding_box = draw_trajectories_bounding_box = False

maybe_create_dir(write_dir)
'''
_render_trajectories_skeletons(write_dir, frames_path, gt_trajectories_path, trajectories_path,
                               draw_gt_skeleton, draw_trajectories_skeleton,
                               draw_gt_bounding_box, draw_trajectories_bounding_box, specific_person_id, 
                               draw_local_skeleton, gt_trajectories_colour, trajectories_colour)
'''

video = cv2.VideoCapture(video_path)

if (video.isOpened() == False):
    print("Error opening video stream or file")
frame_width = int(video.get(3))
frame_height = int(video.get(4))

output = cv2.VideoWriter('./write_dir/testing03/output_original_00_anomaly.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 30.0, (frame_width, frame_height))

if trajectories_path is not None:
    trajectories_files_names = sorted(os.listdir(trajectories_path))  # 001.csv, 002.csv, ...

frame_id = -1
while (video.isOpened()):
    ret, frame = video.read()
    if ret == True:
        frame_id += 1
        print(frame_id)
        # write trajectories to this frame
        for trajectory_file_name in trajectories_files_names:
            person_id = int(trajectory_file_name.split('.')[0])
            if specific_person_id is not None and specific_person_id != person_id:
                continue
        
            if trajectories_colour is None:
                colour = COLOURS[person_id % len(COLOURS)]
            else:
                colour = (0, 0, 0) if trajectories_colour == 'black' else (0, 0, 255)
            
            trajectory = np.loadtxt(os.path.join(trajectories_path, trajectory_file_name), delimiter=',', ndmin=2)
            trajectory_frames = trajectory[:, 0].astype(np.int32)
            trajectory_coordinates = trajectory[:, 1:]
            if len(trajectory_frames) > 10 and frame_id in trajectory_frames:
                for trajectory_frame_id, skeleton_coordinates in zip(trajectory_frames, trajectory_coordinates):
                    if trajectory_frame_id == frame_id and frame is not None:
                        if draw_local_skeleton:
                            frame = np.full_like(frame, fill_value=255)
                        
                        if draw_trajectories_skeleton:
                            if draw_local_skeleton:
                                height, width = frame.shape[:2]
                                left, right, top, bottom = compute_simple_bounding_box(skeleton_coordinates)
                                bb_center = np.array([(left + right) / 2, (top + bottom) / 2], dtype=np.float32)
                                target_center = np.array([3 * width / 4, height / 2], dtype=np.float32)
                                displacement_vector = target_center - bb_center
                                draw_skeleton(frame, keypoints=skeleton_coordinates.reshape(-1, 2) + displacement_vector,
                                              colour=colour, dotted=True)
                            else:
                                draw_skeleton(frame, keypoints=skeleton_coordinates.reshape(-1, 2), colour=colour, dotted=True)
                    
                        if draw_trajectories_bounding_box:
                            left, right, top, bottom = compute_simple_bounding_box(skeleton_coordinates)
                            bb_center = int(round((left + right) / 2)), int(round((top + bottom) / 2))
                            cv2.circle(frame, center=bb_center, radius=4, color=colour, thickness=-1)
                            draw_rect(frame, pt1=(left, top), pt2=(right, bottom), color=colour, thickness=3, style=None)
                        break
        output.write(frame)
    else:
        break


video.release()
output.release()
cv2.destroyAllWindows()




print('Visualisation successfully rendered to %s' % write_dir)





