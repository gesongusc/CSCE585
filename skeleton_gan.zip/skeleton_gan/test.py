from tbad.autoencoder.data import load_trajectories, load_anomaly_masks
import os
import numpy as np

trajectories_path= '/home/jackplus1/skeleton_based_anomaly_detection-master/data/HR-ShanghaiTech/testing/trajectories/01'

anomaly_masks_path = '/home/jackplus1/skeleton_based_anomaly_detection-master/data/HR-ShanghaiTech/testing/frame_level_masks/01'

#trajectories = load_trajectories(trajectories_path)

file_names = os.listdir(anomaly_masks_path)
masks = {}
for file_name in file_names:
    full_id = file_name.split('.')[0]
    file_path = os.path.join(anomaly_masks_path, file_name)
    masks[full_id] = np.load(file_path)
    print(full_id)
    print(len(masks[full_id]))
    print(masks[full_id])
    



